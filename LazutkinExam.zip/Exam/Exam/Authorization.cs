﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Exam
{
    public partial class Form1 : Form
    {
        Model1 db = new Model1();
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // код авторизации
            if (textBox1.Text == "inspector" && textBox2.Text == "inspector") // если 1 и 2 textbox = inspector то впускает в систему
            {
                Form2 drn = new Form2();
                this.Hide();
                drn.Show();
            }
            else if (textBox1.Text == "" && textBox2.Text == "") // обработка события если не введены никакие значения - необходимо ввести логин и пароль
            {
                MessageBox.Show("Необходимо ввести логин и пароль");
            }
            else // если введены неверные логин и пароль выводим messagebox
            {
                MessageBox.Show("Вы ввели неверный логин или пароль");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
