﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Exam
{
    public partial class Addform : Form
    {
        public Model1 db { get; set; }
        public Addform()
        {
            InitializeComponent();
        }

        private void Addform_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form2 frm2 = new Form2();
            this.Hide();
            frm2.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // событие если не введены данные в поля textbox - выводит нужно ввести все данные
            if (textBox1.Text == "" || textBox2.Text == "" || textBox3.Text == "" || textBox4.Text == "" || textBox5.Text == "" || textBox6.Text == "" || textBox7.Text == "" || textBox8.Text == "" || textBox9.Text == "" || textBox10.Text == "" || textBox11.Text == "" || textBox12.Text == "" || textBox13.Text == "")
            {
                MessageBox.Show("Нужно ввести все требуемые данные!");
                return;
            }
            // преобразуем данные из textBox1 (поля ID) в целый тип
            int id;
            bool b = int.TryParse(textBox1.Text, out id);
            if (b == false)
            {
                MessageBox.Show("Неверный формат ID - " + textBox1.Text);
                return;
            }
            // создаем новый объект для коллекции Drivers
            Drivers Drv = new Drivers();
            // задаем свойства объекта
            Drv.ID = id;
            Drv.LastName = textBox2.Text;
            Drv.Name = textBox3.Text;
            Drv.MiddleName = textBox4.Text;
            Drv.PassportSerial = textBox5.Text;
            Drv.PassportNomer = textBox6.Text;
            Drv.Adress = textBox7.Text;
            Drv.Adresslive = textBox8.Text;
            Drv.Company = textBox9.Text;
            Drv.Jobname = textBox10.Text;
            Drv.PhoneNumber = textBox11.Text;
            Drv.Email = textBox12.Text;
            Drv.Photo = textBox13.Text;
            Drv.Description = textBox14.Text;
            // добавляем новый объект к коллекции
            db.Drivers.Add(Drv);
            try
            {
                // сохраняем изменения коллекции в БД
                db.SaveChanges();
                // задаем свойство DialogResult, чтобы закрыть форму
                DialogResult = DialogResult.OK;
            }
            catch (Exception ex)
            { // сложная конструкция для показа сообщений сервера БД
               MessageBox.Show(ex.InnerException.InnerException.Message);
            }
            Update();
        }
    }
}
