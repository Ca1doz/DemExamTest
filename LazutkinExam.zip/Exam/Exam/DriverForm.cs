﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Exam
{
    public partial class Form2 : Form
    {
        Model1 db = new Model1();
        public Form2()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form1 frm1 = new Form1();
            this.Hide();
            frm1.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Addform add = new Addform();
            

            add.db = db;

            DialogResult dr = add.ShowDialog();

            if (dr == DialogResult.OK)
            { // если данные были добавлены к БД, то обновляем содержание 
              // промежуточного объекта!
                driversBindingSource.DataSource = db.Drivers.ToList();
                Update();
            }
        }

        private void DriverForm_Load(object sender, EventArgs e)
        {
            driversBindingSource.DataSource = db.Drivers.ToList();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Drivers dv = (Drivers)driversBindingSource.Current;
            // показываем диалоговое окно с кнопками Yes и No
            DialogResult dr = MessageBox.Show("Вы действительно хотите удалить запись в таблице? - " + dv.ID.ToString(), "Удаление записи", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            // если пользователь нажал кнопку «Да», то удаляем данные из БД
            if (dr == DialogResult.Yes)
            {
                // удаление записи из базы данных
                db.Drivers.Remove(dv);
                try
                {
                    db.SaveChanges();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
                driversBindingSource.DataSource = db.Drivers.ToList();

            }
        }
    }
}